import React from 'react';
import { GameShowPage } from './pages/GameShowPage';
export function App() {
  return <GameShowPage />;
}